chrome.devtools.panels.create('HackBar', 'images/icon.png', 'index.html')
